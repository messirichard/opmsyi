<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'REST_Ongkir.php';

class Ongkir extends Curl_Ongkir
{
}